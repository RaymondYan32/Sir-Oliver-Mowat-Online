You are Red Circle
right click anywhere inside the grid to move
left click other cirlces to  check them out
dbl left click other circles to close in and fight
Basic death/respawn feature has been added
click on red circles of character/inventory tab to close
Both tabs may be moved around by clicking and dragging the top grey like any file
Tabs may be closed and reopened by left clicking the black squares on the bottom right
